document.addEventListener("DOMContentLoaded", () => {
  const params = new URLSearchParams(window.location.search);
  const label = parseInt(params.get("label"), 10);
  const url = params.get("url");

  const messageEl = document.getElementById("warning-message");
  const urlEl = document.getElementById("blocked-url");

  let currentLabel = label;

  if (label === 1) {
    messageEl.innerText = "Situs ini terindikasi sebagai situs Judi Online!";
  } else if (label === 2) {
    messageEl.innerText = "Situs ini terindikasi sebagai situs Pornografi!";
  } else if (label === 3) {
    messageEl.innerText = "Situs ini terindikasi sebagai situs Pembajakan!";
  } else {
    currentLabel = 1;
  }

  if (url) {
    try {
      let domain = new URL(url).hostname;
      if (domain.length > 30) {
        domain = domain.substring(0, 27) + "...";
      }
      urlEl.innerText = `Domain yang diblokir: ${domain}`;
    } catch (e) {
      let displayUrl = url.length > 30 ? url.substring(0, 27) + "..." : url;
      urlEl.innerText = `Domain yang diblokir: ${displayUrl}`;
    }
  }

  const closeBtn = document.getElementById("close-btn");
  if (closeBtn) {
    closeBtn.addEventListener("click", () => {
      window.close();
    });
  }
});
