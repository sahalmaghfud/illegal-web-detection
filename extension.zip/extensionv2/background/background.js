const SERVER_URL = "http://13.250.9.37:8000";

function getDomain(url) {
  try {
    const urlObj = new URL(url);
    return urlObj.hostname;
  } catch (e) {
    return null;
  }
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "CHECK_PAGE") {
    // Ack immediately to prevent message port closing
    sendResponse({ received: true });
    processPageCheck(request.url, sender.tab.id, sender.tab.windowId);
  }
  return true;
});

async function processPageCheck(url, tabId, windowId) {
  const domain = getDomain(url);
  if (!domain) return;

  console.log("Checking URL:", url);

  try {
    // Tahap 1: Cek penyimpanan lokal chrome
    const storageResult = await chrome.storage.local.get([domain]);
    if (storageResult[domain] !== undefined) {
      console.log(
        "Data ditemukan pada penyimpanan lokal:",
        storageResult[domain],
      );
      blockTab(tabId, storageResult[domain], url);
      return;
    }

    // Tahap 2: Cek di API /check-domain
    try {
      const checkUrlResponse = await fetch(
        `${SERVER_URL}/check-domain?url=${encodeURIComponent(url)}`,
      );
      if (checkUrlResponse.ok) {
        const checkUrlData = await checkUrlResponse.json();
        if (checkUrlData.in_list) {
          console.log(
            "Data ditemukan pada API /check-domain:",
            checkUrlData.label,
          );
          await chrome.storage.local.set({ [domain]: checkUrlData.label });
          blockTab(tabId, checkUrlData.label, url);
          return;
        }
      }
    } catch (e) {
      console.error("API /check-domain error:", e);
    }

    // Tahap 3: Cek di API /predict
    chrome.tabs.sendMessage(
      tabId,
      { action: "REQUEST_FEATURES" },
      async (featuresResponse) => {
        if (chrome.runtime.lastError || !featuresResponse) {
          console.error(
            "Gagal mendapatkan fitur dari content script:",
            chrome.runtime.lastError?.message,
          );
          return;
        }

        try {
          // Delay render sebelum mengambil screenshot
          await new Promise((r) => setTimeout(r, 500));
          const imageBase64DataUrl = await chrome.tabs.captureVisibleTab(
            windowId,
            { format: "jpeg", quality: 50 },
          );
          const predictPayload = {
            url: url,
            text_content: featuresResponse.textContent,
            image_base64: imageBase64DataUrl,
            html_features: featuresResponse.htmlFeatures,
          };

          const predictResponse = await fetch(`${SERVER_URL}/predict`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(predictPayload),
          });

          if (predictResponse.ok) {
            const predictData = await predictResponse.json();
            console.log(
              "Website berhasil diprediksi pada API /predict",
              predictData.label,
            );
            await chrome.storage.local.set({ [domain]: predictData.label });
            blockTab(tabId, predictData.label, url);
          } else {
            console.error("API /predict error", predictResponse.status);
          }
        } catch (e) {
          console.error("Layer 4 error:", e);
        }
      },
    );
  } catch (error) {
    console.error("Process page check error:", error);
  }
}

function blockTab(tabId, label, url) {
  if (label > 0) {
    const blockedUrl = chrome.runtime.getURL(
      `pages/blocked.html?label=${label}&url=${encodeURIComponent(url)}`,
    );
    chrome.tabs.update(tabId, { url: blockedUrl }).catch(() => {});
  }
}

chrome.runtime.onInstalled.addListener(async () => {
  const data = await chrome.storage.local.get(["admin_pin"]);
  if (!data.admin_pin) {
    chrome.tabs.create({ url: chrome.runtime.getURL("pages/init.html") });
  }

  // Load domains.json into local storage
  try {
    const url = chrome.runtime.getURL("data/domains.json");
    const response = await fetch(url);
    const domainsData = await response.json();
    await chrome.storage.local.set(domainsData);
    console.log("domains.json loaded into local storage.");
  } catch (e) {
    console.error("Error loading domains.json on install:", e);
  }
});
